# OutieApp
Part of She's Coding Codeathon - Weather App that helps you decide what to wear.

Most instructions are here:
https://facebook.github.io/react-native/docs/getting-started.html

todo: download Xcode

IN YOUR TERMINAL:
```
brew install node 
brew install watchman
npm install -g react-native-cli

cd your-root-to/OutieApp
react-native run-ios
```
