export const ADD_SELFIE = "ADD_SELFIE";
